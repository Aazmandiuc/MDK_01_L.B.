class PasswordApp:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def login(self, entered_username, entered_password):
        if entered_username == self.username and entered_password == self.password:
            print("Добро пожаловать.")
            student1 = Student('Никита', 'Куделя')
            date1 = '05.12.23'
            print('Отчет о посещаемости студента:')

            print(student1)
            print(date1)

            date = Attendence(date1)
            res = date.check(date1)

            print(res)
        else:
            print("Ошибка входа.")

class Attendence:
    def __init__(self, date):
        self.date = date

    def check(self, check_date):
        if check_date == self.date:
            return 'был(а) в этот день'
        else:
            return 'не было в этот день'


class Student:
    def __init__(self, name, lastname):
        self.name = name
        self.lastname = lastname
    def __str__(self):
        return f"{self.name} {self.lastname}"
    def __eq__(self, other):
        return self.name == other.name
    def __gt__(self, other):
        return self.name > other.name

username = input("Введите логин: ")
password = input("Введите пароль: ")
curator= PasswordApp("admin", "pas")
result = curator.login(username, password)
