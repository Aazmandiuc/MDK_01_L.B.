
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QMenuBar
from PyQt6.QtGui import QAction
from curator import WindowForCurator
from starosta import WindowForStarosta

class PassWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Журнал посещаемости')
        self.resize(300, 200)

        v_layout = QVBoxLayout()

        #ввод имя пользователя
        self.username_label = QLabel('Имя пользователя:')
        #строка для ввода имени пользователя
        self.username_input = QLineEdit()

        # ввод пароля
        self.password_label = QLabel('Пароль:')
        # строка для ввода пароля
        self.password_input = QLineEdit()
        self.password_input.setEchoMode((QLineEdit.EchoMode.Password))

        self.login_btn = QPushButton('Вход')
        self.login_btn.clicked.connect(self.check_password)


        #менюбар о программе
        menubar = QMenuBar()
        about_menu = menubar.addMenu('О программе')

        about_action = QAction('О приложении', self)
        about_action.triggered.connect(self.showAbout)

        about_menu.addAction(about_action)


        #меню бар выход
        exit_menu = menubar.addMenu('Выход')

        exit_action = QAction('Выйти из приложения', self)
        exit_action.triggered.connect(self.vihod)

        exit_menu.addAction(exit_action)

        #расположение виджетов
        v_layout.addWidget(self.username_label)
        v_layout.addWidget(self.username_input)
        v_layout.addWidget(self.password_label)
        v_layout.addWidget(self.password_input)
        v_layout.addWidget(self.login_btn)

        v_layout.setMenuBar(menubar)

        self.setLayout(v_layout)

    #вызов окна о приложении
    def showAbout(self):
        QMessageBox.about(self,'О приложении', 'Приложение для отметки посещаемости')

    #выход
    def vihod(self):
        win.close()


    #Сообщение об ошибке
    def show_error_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()

    #открытие окна
    def open_window(self, role):
        self.close()

        if role == 'curator':
            self.window == WindowForCurator()
        elif role == 'starosta':
            self.window == WindowForStarosta()
        else:
            self.show_error_message('Ошибка','Неизвестный пользователь')
            return
        self.window.show()


    #проверка пароля
    def check_password(self):
        username = self.username_input.text()
        password = self.password_input.text()

        for user in users:
            if username == user.username and password == user.password:
                self.open_window(user.role)
                return
        self.show_error_message('Ошибка авторизации', 'Неверное имя пользователя или пароль')

#класс пользователя
class User:
    def __init__(self, username, password, role):
        self.username = username
        self.password = password
        self.role = role

users = [User('starosta1', 'password1', 'starosta'),
         User('curator1', 'password2', ' curator')]



app = QApplication([])
win = PassWindow()
win.show()
app.exec()