from PyQt6.QtWidgets import QWidget, QDialog

class WindowForCurator(QWidget):
    def __init__(self):
        super().__init__()

        new_win = QDialog(self)
        new_win.setWindowTitle('Окно куратора')
        new_win.resize(300,300)
        new_win.exec()